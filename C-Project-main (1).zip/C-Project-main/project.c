#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

//TASK STRUCT
typedef struct {
    void (*function)(void *);  
    void *arg;                 
} Task;

//THREAD POOL
#define MAX_TASKS 10

Task taskQueue[MAX_TASKS];
int front = 0, rear = 0, count = 0;

pthread_mutex_t lock;
pthread_cond_t cond;

int stop = 0; 

// QUEUE FUNCTIONS
void addTask(void (*function)(void *), void *arg) {
    pthread_mutex_lock(&lock);

    if (count == MAX_TASKS) {
        printf("Queue full! Waiting for space...\n");
        while (count == MAX_TASKS)
            pthread_cond_wait(&cond, &lock);
    }

    taskQueue[rear].function = function;
    taskQueue[rear].arg = arg;
    rear = (rear + 1) % MAX_TASKS;
    count++;

    pthread_cond_signal(&cond);
    pthread_mutex_unlock(&lock);
}

Task getTask() {
    Task task = {NULL, NULL};
    pthread_mutex_lock(&lock);

    while (count == 0 && !stop) {
        pthread_cond_wait(&cond, &lock);
    }

    if (stop) {
        pthread_mutex_unlock(&lock);
        return task;
    }

    task = taskQueue[front];
    front = (front + 1) % MAX_TASKS;
    count--;

    pthread_cond_signal(&cond);
    pthread_mutex_unlock(&lock);
    return task;
}

//WORKER FUNCTION
void* worker(void* arg) {
    int id = *(int*)arg;

    while (!stop) {
        Task task = getTask();
        if (task.function) {
            printf("Worker %d executing a task...\n", id);
            task.function(task.arg);
            printf("Worker %d finished a task!\n\n", id);
        }
    }
    return NULL;
}

// REAL TASKS
void printMessage(void *arg) {
    char *msg = (char*)arg;
    printf("Message: %s\n", msg);
    sleep(1);
}

void calculateSum(void *arg) {
    int n = *(int*)arg;
    int sum = 0;
    for (int i = 1; i <= n; i++) sum += i;
    printf("Sum of 1 to %d = %d\n", n, sum);
    sleep(1);
}

void calculateFactorial(void *arg) {
    int n = *(int*)arg;
    int fact = 1;
    for (int i = 1; i <= n; i++) fact *= i;
    printf("Factorial of %d = %d\n", n, fact);
    sleep(1);
}

//MAIN FUNCTION
int main() {
    int numThreads = 3;
    pthread_t threads[numThreads];
    int ids[numThreads];

    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&cond, NULL);

    
    for (int i = 0; i < numThreads; i++) {
        ids[i] = i + 1;
        pthread_create(&threads[i], NULL, worker, &ids[i]);
    }

   
    char *msg1 = "Hello from ThreadPool!";
    addTask(printMessage, msg1);

    int n1 = 5;
    addTask(calculateSum, &n1);

    int n2 = 6;
    addTask(calculateFactorial, &n2);

    char *msg2 = "Learning Threads is fun!";
    addTask(printMessage, msg2);

    
    sleep(5);

   
    pthread_mutex_lock(&lock);
    stop = 1;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&lock);

    for (int i = 0; i < numThreads; i++)
        pthread_join(threads[i], NULL);

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&cond);

    printf("All tasks completed. Thread pool shutting down.\n");
    return 0;
}
