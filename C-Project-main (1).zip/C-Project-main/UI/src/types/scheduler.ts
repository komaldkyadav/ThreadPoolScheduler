export type TaskStatus = 'pending' | 'running' | 'completed';

export interface Task {
  id: string;
  name: string;
  type: 'printMessage' | 'calculateSum' | 'calculateFactorial';
  status: TaskStatus;
  duration: number;
  result?: string;
}

export interface Worker {
  id: number;
  status: 'idle' | 'busy';
  currentTask: Task | null;
}

export interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
  type: 'info' | 'success' | 'warning';
}
