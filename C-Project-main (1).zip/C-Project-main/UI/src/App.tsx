import { useThreadPool } from './hooks/useThreadPool';
import { Header } from './components/Header';
import { ControlPanel } from './components/ControlPanel';
import { TaskQueue } from './components/TaskQueue';
import { WorkerPool } from './components/WorkerPool';
import { LogPanel } from './components/LogPanel';

function App() {
  const {
    tasks,
    workers,
    logs,
    isRunning,
    addTask,
    startScheduler,
    stopScheduler,
    clearCompleted,
  } = useThreadPool();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-slate-900 to-black text-white p-8">
      <div className="max-w-7xl mx-auto">
        <Header />

        <div className="space-y-6">
          <ControlPanel
            isRunning={isRunning}
            onAddTask={addTask}
            onStart={startScheduler}
            onStop={stopScheduler}
            onClearCompleted={clearCompleted}
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TaskQueue tasks={tasks} />
            <WorkerPool workers={workers} />
          </div>

          <LogPanel logs={logs} />
        </div>
      </div>
    </div>
  );
}

export default App;
