import { motion } from 'framer-motion';
import { Plus, Play, Square, Trash2 } from 'lucide-react';

interface ControlPanelProps {
  isRunning: boolean;
  onAddTask: () => void;
  onStart: () => void;
  onStop: () => void;
  onClearCompleted: () => void;
}

export const ControlPanel = ({
  isRunning,
  onAddTask,
  onStart,
  onStop,
  onClearCompleted,
}: ControlPanelProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gray-900/50 rounded-xl border-2 border-gray-700/50 backdrop-blur-sm p-6"
    >
      <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
        <Square className="w-5 h-5 text-cyan-400" />
        Control Panel
      </h3>
      <div className="flex flex-wrap gap-3">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onAddTask}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold rounded-lg shadow-lg shadow-cyan-500/30 transition-all"
        >
          <Plus className="w-5 h-5" />
          Add Task
        </motion.button>

        {!isRunning ? (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onStart}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 text-white font-semibold rounded-lg shadow-lg shadow-green-500/30 transition-all"
          >
            <Play className="w-5 h-5" />
            Start Scheduler
          </motion.button>
        ) : (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={onStop}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold rounded-lg shadow-lg shadow-red-500/30 transition-all"
          >
            <Square className="w-5 h-5" />
            Stop Scheduler
          </motion.button>
        )}

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onClearCompleted}
          className="flex items-center gap-2 px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white font-semibold rounded-lg shadow-lg transition-all"
        >
          <Trash2 className="w-5 h-5" />
          Clear Completed
        </motion.button>
      </div>
    </motion.div>
  );
};
