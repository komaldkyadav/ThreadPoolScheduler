import { motion } from 'framer-motion';
import { Clock, CheckCircle, Play } from 'lucide-react';
import { Task } from '../types/scheduler';

interface TaskCardProps {
  task: Task;
}

export const TaskCard = ({ task }: TaskCardProps) => {
  const getStatusColor = () => {
    switch (task.status) {
      case 'pending':
        return 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300';
      case 'running':
        return 'bg-blue-500/20 border-blue-500/50 text-blue-300';
      case 'completed':
        return 'bg-green-500/20 border-green-500/50 text-green-300';
    }
  };

  const getStatusIcon = () => {
    switch (task.status) {
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'running':
        return <Play className="w-4 h-4 animate-pulse" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
    }
  };

  const getStatusLabel = () => {
    switch (task.status) {
      case 'pending':
        return 'Pending';
      case 'running':
        return 'Running';
      case 'completed':
        return 'Completed';
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className={`p-4 rounded-lg border-2 ${getStatusColor()} backdrop-blur-sm transition-all duration-300`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm truncate">{task.name}</h3>
          <p className="text-xs opacity-70 mt-1">{task.duration}ms duration</p>
          {task.result && (
            <p className="text-xs opacity-90 mt-2 font-mono">{task.result}</p>
          )}
        </div>
        <div className="flex flex-col items-end gap-1">
          {getStatusIcon()}
          <span className="text-xs font-medium">{getStatusLabel()}</span>
        </div>
      </div>
    </motion.div>
  );
};
