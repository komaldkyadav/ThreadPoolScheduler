import { motion, AnimatePresence } from 'framer-motion';
import { List } from 'lucide-react';
import { Task } from '../types/scheduler';
import { TaskCard } from './TaskCard';

interface TaskQueueProps {
  tasks: Task[];
}

export const TaskQueue = ({ tasks }: TaskQueueProps) => {
  const pendingTasks = tasks.filter((t) => t.status === 'pending');
  const runningTasks = tasks.filter((t) => t.status === 'running');
  const completedTasks = tasks.filter((t) => t.status === 'completed');

  return (
    <div className="bg-gray-900/50 rounded-xl border-2 border-gray-700/50 backdrop-blur-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <List className="w-5 h-5 text-cyan-400" />
          Task Queue
        </h3>
        <div className="flex gap-4 text-sm">
          <span className="text-yellow-400">⬤ Pending: {pendingTasks.length}</span>
          <span className="text-blue-400">⬤ Running: {runningTasks.length}</span>
          <span className="text-green-400">⬤ Completed: {completedTasks.length}</span>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent">
        <AnimatePresence mode="popLayout">
          {tasks.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-12 text-gray-600"
            >
              <List className="w-16 h-16 mx-auto mb-3 opacity-50" />
              <p className="text-sm">No tasks in queue. Add some tasks to get started!</p>
            </motion.div>
          ) : (
            tasks.map((task) => <TaskCard key={task.id} task={task} />)
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
