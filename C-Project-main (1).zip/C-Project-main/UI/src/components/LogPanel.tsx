import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Info, CheckCircle, AlertTriangle } from 'lucide-react';
import { LogEntry } from '../types/scheduler';

interface LogPanelProps {
  logs: LogEntry[];
}

export const LogPanel = ({ logs }: LogPanelProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const getLogIcon = (type: LogEntry['type']) => {
    switch (type) {
      case 'info':
        return <Info className="w-4 h-4 text-blue-400" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
    }
  };

  const getLogColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'info':
        return 'text-blue-300';
      case 'success':
        return 'text-green-300';
      case 'warning':
        return 'text-yellow-300';
    }
  };

  return (
    <div className="bg-gray-900/50 rounded-xl border-2 border-gray-700/50 backdrop-blur-sm overflow-hidden">
      <div className="bg-gray-800/70 px-4 py-3 border-b border-gray-700/50 flex items-center gap-2">
        <Terminal className="w-5 h-5 text-cyan-400" />
        <h3 className="font-semibold text-white">System Logs</h3>
        <span className="ml-auto text-xs text-gray-400">{logs.length} entries</span>
      </div>

      <div
        ref={scrollRef}
        className="h-64 overflow-y-auto p-4 space-y-2 font-mono text-sm scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-transparent"
      >
        <AnimatePresence initial={false}>
          {logs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              className="flex items-start gap-3 p-2 rounded bg-black/20 hover:bg-black/40 transition-colors"
            >
              {getLogIcon(log.type)}
              <span className="text-gray-500 text-xs min-w-[80px]">{log.timestamp}</span>
              <span className={`flex-1 ${getLogColor(log.type)}`}>{log.message}</span>
            </motion.div>
          ))}
        </AnimatePresence>

        {logs.length === 0 && (
          <div className="text-center text-gray-600 py-8">
            <Terminal className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No logs yet. Start the scheduler to see activity.</p>
          </div>
        )}
      </div>
    </div>
  );
};
