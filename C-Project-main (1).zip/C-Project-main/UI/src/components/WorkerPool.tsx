import { motion } from 'framer-motion';
import { Cpu } from 'lucide-react';
import { Worker } from '../types/scheduler';
import { WorkerCard } from './WorkerCard';

interface WorkerPoolProps {
  workers: Worker[];
}

export const WorkerPool = ({ workers }: WorkerPoolProps) => {
  const idleCount = workers.filter((w) => w.status === 'idle').length;
  const busyCount = workers.filter((w) => w.status === 'busy').length;

  return (
    <div className="bg-gray-900/50 rounded-xl border-2 border-gray-700/50 backdrop-blur-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Cpu className="w-5 h-5 text-cyan-400" />
          Worker Pool
        </h3>
        <div className="flex gap-4 text-sm">
          <span className="text-green-400">⬤ Idle: {idleCount}</span>
          <span className="text-blue-400">⬤ Busy: {busyCount}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {workers.map((worker, index) => (
          <motion.div
            key={worker.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <WorkerCard worker={worker} />
          </motion.div>
        ))}
      </div>
    </div>
  );
};
