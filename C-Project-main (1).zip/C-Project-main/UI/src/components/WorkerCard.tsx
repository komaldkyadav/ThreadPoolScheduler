import { motion } from 'framer-motion';
import { Cpu, Circle } from 'lucide-react';
import { Worker } from '../types/scheduler';

interface WorkerCardProps {
  worker: Worker;
}

export const WorkerCard = ({ worker }: WorkerCardProps) => {
  const isBusy = worker.status === 'busy';

  return (
    <motion.div
      layout
      className={`p-5 rounded-xl border-2 backdrop-blur-sm transition-all duration-300 ${
        isBusy
          ? 'bg-blue-500/20 border-blue-400/50 shadow-lg shadow-blue-500/20'
          : 'bg-gray-800/40 border-gray-700/50'
      }`}
    >
      <div className="flex items-center gap-3 mb-3">
        <div
          className={`p-2 rounded-lg ${
            isBusy ? 'bg-blue-500/30' : 'bg-gray-700/50'
          }`}
        >
          <Cpu className={`w-5 h-5 ${isBusy ? 'text-blue-300' : 'text-gray-400'}`} />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-white">Worker {worker.id}</h3>
          <div className="flex items-center gap-2 mt-1">
            <Circle
              className={`w-2 h-2 ${
                isBusy ? 'fill-blue-400 text-blue-400 animate-pulse' : 'fill-green-400 text-green-400'
              }`}
            />
            <span className={`text-xs ${isBusy ? 'text-blue-300' : 'text-green-300'}`}>
              {isBusy ? 'Busy' : 'Idle'}
            </span>
          </div>
        </div>
      </div>

      {worker.currentTask ? (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 p-3 bg-black/30 rounded-lg border border-blue-500/30"
        >
          <p className="text-xs text-gray-400 mb-1">Executing:</p>
          <p className="text-sm text-white font-medium">{worker.currentTask.name}</p>
          <div className="mt-2 h-1 bg-gray-700 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
              initial={{ width: '0%' }}
              animate={{ width: '100%' }}
              transition={{ duration: worker.currentTask.duration / 1000, ease: 'linear' }}
            />
          </div>
        </motion.div>
      ) : (
        <div className="mt-3 p-3 bg-black/20 rounded-lg border border-gray-700/30">
          <p className="text-xs text-gray-500 text-center">Waiting for task...</p>
        </div>
      )}
    </motion.div>
  );
};
