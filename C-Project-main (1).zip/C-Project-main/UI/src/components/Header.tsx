import { motion } from 'framer-motion';
import { Layers } from 'lucide-react';

export const Header = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="text-center mb-8"
    >
      <div className="flex items-center justify-center gap-3 mb-3">
        <motion.div
          animate={{
            rotate: [0, 360],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'linear',
          }}
        >
          <Layers className="w-10 h-10 text-cyan-400" />
        </motion.div>
        <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
          Thread Pool Scheduler
        </h1>
      </div>
      <p className="text-gray-400 text-lg max-w-2xl mx-auto">
        A visual simulation of thread pool scheduling and task execution. Watch as workers pick up
        tasks from the queue and execute them concurrently.
      </p>
    </motion.div>
  );
};
