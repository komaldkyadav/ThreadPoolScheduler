import { useState, useCallback, useRef } from 'react';
import { Task, Worker, LogEntry, TaskStatus } from '../types/scheduler';

const WORKER_COUNT = 4;

const TASK_TYPES = [
  { type: 'printMessage' as const, name: 'Print Message', duration: 2000 },
  { type: 'calculateSum' as const, name: 'Calculate Sum', duration: 3000 },
  { type: 'calculateFactorial' as const, name: 'Calculate Factorial', duration: 4000 },
];

export const useThreadPool = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [workers, setWorkers] = useState<Worker[]>(
    Array.from({ length: WORKER_COUNT }, (_, i) => ({
      id: i + 1,
      status: 'idle' as const,
      currentTask: null,
    }))
  );
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const addLog = useCallback((message: string, type: LogEntry['type'] = 'info') => {
    const newLog: LogEntry = {
      id: Date.now().toString() + Math.random(),
      timestamp: new Date().toLocaleTimeString(),
      message,
      type,
    };
    setLogs((prev) => [...prev, newLog]);
  }, []);

  const addTask = useCallback(() => {
    const randomTask = TASK_TYPES[Math.floor(Math.random() * TASK_TYPES.length)];
    const newTask: Task = {
      id: Date.now().toString() + Math.random(),
      name: randomTask.name,
      type: randomTask.type,
      status: 'pending',
      duration: randomTask.duration,
    };
    setTasks((prev) => [...prev, newTask]);
    addLog(`Task "${newTask.name}" added to queue`, 'info');
  }, [addLog]);

  const executeTask = useCallback(
    (worker: Worker, task: Task) => {
      setTasks((prev) =>
        prev.map((t) => (t.id === task.id ? { ...t, status: 'running' as TaskStatus } : t))
      );

      setWorkers((prev) =>
        prev.map((w) =>
          w.id === worker.id ? { ...w, status: 'busy' as const, currentTask: task } : w
        )
      );

      addLog(`Worker ${worker.id} started executing "${task.name}"`, 'info');

      setTimeout(() => {
        let result = '';
        switch (task.type) {
          case 'printMessage':
            result = 'Message printed successfully';
            break;
          case 'calculateSum':
            result = 'Sum = 12345';
            break;
          case 'calculateFactorial':
            result = 'Factorial = 3628800';
            break;
        }

        setTasks((prev) =>
          prev.map((t) =>
            t.id === task.id ? { ...t, status: 'completed' as TaskStatus, result } : t
          )
        );

        setWorkers((prev) =>
          prev.map((w) =>
            w.id === worker.id ? { ...w, status: 'idle' as const, currentTask: null } : w
          )
        );

        addLog(`Worker ${worker.id} completed "${task.name}" - ${result}`, 'success');
      }, task.duration);
    },
    [addLog]
  );

  const scheduleNextTask = useCallback(() => {
    setWorkers((currentWorkers) => {
      setTasks((currentTasks) => {
        const pendingTasks = currentTasks.filter((t) => t.status === 'pending');
        const idleWorkers = currentWorkers.filter((w) => w.status === 'idle');

        idleWorkers.forEach((worker) => {
          const nextTask = pendingTasks.find((t) => t.status === 'pending');
          if (nextTask) {
            executeTask(worker, nextTask);
            pendingTasks.splice(pendingTasks.indexOf(nextTask), 1);
          }
        });

        return currentTasks;
      });
      return currentWorkers;
    });
  }, [executeTask]);

  const startScheduler = useCallback(() => {
    if (isRunning) return;
    setIsRunning(true);
    addLog('Thread Pool Scheduler started', 'success');

    intervalRef.current = setInterval(() => {
      scheduleNextTask();
    }, 500);
  }, [isRunning, addLog, scheduleNextTask]);

  const stopScheduler = useCallback(() => {
    if (!isRunning) return;
    setIsRunning(false);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    addLog('Thread Pool Scheduler stopped', 'warning');
  }, [isRunning, addLog]);

  const clearCompleted = useCallback(() => {
    setTasks((prev) => prev.filter((t) => t.status !== 'completed'));
    addLog('Completed tasks cleared', 'info');
  }, [addLog]);

  return {
    tasks,
    workers,
    logs,
    isRunning,
    addTask,
    startScheduler,
    stopScheduler,
    clearCompleted,
  };
};
